import { system } from '@minecraft/server';

const OFFSETS = [-0.29, 0, 0.29];

const scanGround = (dim, loc) => {
    let closest = { block: null, distance: Infinity };
    
    for (const dx of OFFSETS) {
        for (const dz of OFFSETS) {
            const checkLoc = { x: loc.x + dx, y: loc.y, z: loc.z + dz };
            
            const snowRay = dim.getBlockFromRay(checkLoc, { x: 0, y: -1, z: 0 }, 
                { maxDistance: 2, includePassableBlocks: true, includeLiquidBlocks: false });
            
            if (snowRay?.block?.typeId === 'minecraft:snow_layer') {
                const dist = loc.y - (snowRay.block.location.y + 0.125);
                if (dist < closest.distance) {
                    closest.distance = dist;
                    closest.block = snowRay.block;
                }
            }
            
            const ray = dim.getBlockFromRay(checkLoc, { x: 0, y: -1, z: 0 }, 
                { maxDistance: 2, includePassableBlocks: false, includeLiquidBlocks: false });
            
            if (ray?.block) {
                const dist = loc.y - (ray.block.location.y + 1);
                if (dist < closest.distance) {
                    closest.distance = dist;
                    closest.block = ray.block;
                }
            }
        }
    }
    
    return closest;
};

const scanObstacles = (dim, loc, moveDir, groundBlock) => {
    const yLevels = [0.13, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7];
    const hasMovement = moveDir.x !== 0 || moveDir.z !== 0;
    
    if (!hasMovement) return false;
    
    const dirMag = Math.sqrt(moveDir.x * moveDir.x + moveDir.z * moveDir.z);
    const normDir = { 
        x: moveDir.x / dirMag, 
        z: moveDir.z / dirMag 
    };
    
    const groundY = groundBlock ? groundBlock.location.y + 1 : loc.y;
    
    for (const dx of OFFSETS) {
        for (const dz of OFFSETS) {
            const startLoc = { 
                x: loc.x + dx, 
                y: loc.y, 
                z: loc.z + dz 
            };
            
            for (const yOff of yLevels) {
                const scanPos = { x: startLoc.x, y: startLoc.y + yOff, z: startLoc.z };
                const scanDir = { x: normDir.x, y: 0, z: normDir.z };
                
                const snowRay = dim.getBlockFromRay(
                    scanPos,
                    scanDir,
                    { maxDistance: 1, includePassableBlocks: true, includeLiquidBlocks: false }
                );
                
                if (snowRay?.block?.typeId === 'minecraft:snow_layer') {
                    return true;
                }
                
                const ray = dim.getBlockFromRay(
                    scanPos,
                    scanDir,
                    { maxDistance: 1, includePassableBlocks: false, includeLiquidBlocks: false }
                );
                
                if (ray?.block && !ray.block.isAir && !ray.block.isLiquid) {
                    const distance = ray.distance ?? 0;
                    
                    if (distance <= 0.05) {
                        return true;
                    }
                }
            }
        }
    }
    
    return false;
};

const scanGaps = (dim, loc, moveDir, groundBlock) => {
    const hasMovement = moveDir.x !== 0 || moveDir.z !== 0;
    const fwdOff = hasMovement ? 0.05 : 0;
    const xOff = moveDir.x * fwdOff;
    const zOff = moveDir.z * fwdOff;
    
    const gaps = { low: false, high: false };
    
    const groundY = groundBlock ? groundBlock.location.y + 1 : loc.y;
    const scanBase = groundY + 0.1;
    const maxLowHeight = scanBase + 1.0;
    const maxHighHeight = scanBase + 1.8;
    
    for (const dx of OFFSETS) {
        for (const dz of OFFSETS) {
            const checkLoc = { 
                x: loc.x + xOff + dx, 
                y: scanBase, 
                z: loc.z + zOff + dz 
            };
            
            const gap1 = dim.getBlockFromRay(
                checkLoc,
                { x: 0, y: 1, z: 0 },
                { maxDistance: 1, includePassableBlocks: false, includeLiquidBlocks: false }
            );
            
            const gap2 = dim.getBlockFromRay(
                checkLoc,
                { x: 0, y: 1, z: 0 },
                { maxDistance: 2, includePassableBlocks: false, includeLiquidBlocks: false }
            );
            
            if (gap1?.block && !gap1.block.isAir && gap1.block.location.y <= maxLowHeight) gaps.low = true;
            if (gap2?.block && !gap2.block.isAir && gap2.block.location.y <= maxHighHeight) gaps.high = true;
        }
    }
    
    return gaps;
};

const scanVault = (dim, loc, rot, groundDistance) => {
    const bodyYawRad = rot.y * (Math.PI / 180);
    const bodyDir = { x: -Math.sin(bodyYawRad), z: Math.cos(bodyYawRad) };
    
    const minVault = loc.y + 1.0;
    const maxVault = loc.y + 1.4;
    const scanLimit = loc.y + 3;
    
    let foundSolid = false;
    let tooHigh = false;
    let tooLow = true;
    let hitDist = Infinity;
    let isSpecialBlock = false;
    
    for (let scanY = loc.y; scanY <= scanLimit; scanY += 0.1) {
        const ray = dim.getBlockFromRay(
            { x: loc.x, y: scanY, z: loc.z },
            { x: bodyDir.x, y: 0, z: bodyDir.z },
            { maxDistance: 1, includePassableBlocks: false, includeLiquidBlocks: false }
        );
        
        if (ray?.block && !ray.block.isAir && !ray.block.isLiquid) {
            foundSolid = true;
            
            const blockType = ray.block.typeId;
            isSpecialBlock = blockType.includes('fence') || 
                            blockType.includes('wall') || 
                            blockType.includes('gate');
            
            const blockX = ray.block.location.x;
            const blockZ = ray.block.location.z;
            const dirX = bodyDir.x;
            const dirZ = bodyDir.z;
            
            let distanceToBlock;
            
            if (Math.abs(dirX) > Math.abs(dirZ)) {
                distanceToBlock = dirX > 0 ? blockX - loc.x : loc.x - (blockX + 1);
            } else {
                distanceToBlock = dirZ > 0 ? blockZ - loc.z : loc.z - (blockZ + 1);
            }
            
            const dist = Math.abs(distanceToBlock);
            if (dist < hitDist && dist > 0) hitDist = dist;
            
            if (scanY > maxVault) {
                tooHigh = true;
                break;
            } else if (scanY >= minVault) {
                tooLow = false;
            }
            
            if (isSpecialBlock || groundDistance >= 1.5) {
                tooLow = false;
            }
        }
    }
    
    return {
        valid: foundSolid && !tooLow && !tooHigh,
        high: tooHigh,
        distance: foundSolid ? hitDist : Infinity,
        isSpecialBlock: isSpecialBlock
    };
};

const scanWalls = (p) => {
    const { location: loc, dimension: dim } = p;
    const viewDir = p.getViewDirection();
    
    const sides = [
        { side: "left", dirX: viewDir.z, dirZ: -viewDir.x },
        { side: "right", dirX: -viewDir.z, dirZ: viewDir.x }
    ];
    
    let leftDistance = Infinity, rightDistance = Infinity;
    let validSide = null;
    
    for (const { side, dirX, dirZ } of sides) {
        const ray = dim.getBlockFromRay(
            { x: loc.x, y: loc.y + 0.8, z: loc.z },
            { x: dirX, y: 0, z: dirZ },
            { maxDistance: 2, includePassableBlocks: false, includeLiquidBlocks: false }
        );
        
        if (ray?.block && !ray.block.isAir && !ray.block.isLiquid) {
            const blockLoc = ray.block.location;
            const dist = Math.sqrt((blockLoc.x + 0.5 - loc.x) ** 2 + (blockLoc.z + 0.5 - loc.z) ** 2) - 0.5;
            
            if (side === "left") leftDistance = dist;
            if (side === "right") rightDistance = dist;
            
            if (dist <= 0.6) {
                validSide = side;
            }
        }
    }
    
    return { side: validSide, leftDistance, rightDistance };
};

const scanLedge = (p, loc, rot, dim, lenient = false) => {
    const bodyYawRad = rot.y * (Math.PI / 180);
    const bodyDir = { x: -Math.sin(bodyYawRad), z: Math.cos(bodyYawRad) };
    const scanHeights = lenient ? [1.2, 1.3, 1.4] : [1.3];
    const maxDistance = 0.7;
    let canGrab = false;
    let grabDist = Infinity;
    
    for (const hOff of scanHeights) {
        const ray = dim.getBlockFromRay(
            { x: loc.x, y: loc.y + hOff, z: loc.z },
            { x: bodyDir.x, y: 0, z: bodyDir.z },
            { maxDistance: 2.0, includePassableBlocks: false, includeLiquidBlocks: false }
        );
        
        if (ray?.block && !ray.block.isAir && !ray.block.isLiquid) {
            const blockX = ray.block.location.x;
            const blockZ = ray.block.location.z;
            const dirX = bodyDir.x;
            const dirZ = bodyDir.z;
            
            let distanceToBlock;
            
            if (Math.abs(dirX) > Math.abs(dirZ)) {
                distanceToBlock = dirX > 0 ? blockX - loc.x : loc.x - (blockX + 1);
            } else {
                distanceToBlock = dirZ > 0 ? blockZ - loc.z : loc.z - (blockZ + 1);
            }
            
            const dist = Math.abs(distanceToBlock);
            
            if (dist <= maxDistance && dist > 0) {
                canGrab = true;
                grabDist = dist;
                break;
            }
        }
    }
    
    return { can: canGrab, type: 'head', distance: grabDist, grabLoc: null };
};

const getMovementDirection = (p) => {
    const rot = p.getRotation();
    const yaw = rot.y * Math.PI / 180;
    const input = p.inputInfo?.getMovementVector() || { x: 0, y: 1 };
    
    return {
        x: input.x * Math.cos(yaw) - input.y * Math.sin(yaw),
        z: input.x * Math.sin(yaw) + input.y * Math.cos(yaw),
        has: input.x !== 0 || input.y !== 0
    };
};

export const BlockScanner = {
    scan: (p, tick, options = {}) => {
        const {
            needGround = false,
            needObstacle = false,
            needGap = false,
            needVault = false,
            needWall = false,
            needLedge = false,
            needMovement = false,
            needLiquid = false,
            lenientLedge = false
        } = options;
        
        const { location: loc, dimension: dim } = p;
        const rot = p.getRotation();
        
        const result = {};
        
        let moveDir = null;
        if (needMovement || needObstacle || needGap) {
            moveDir = getMovementDirection(p);
            if (needMovement) result.movement = moveDir;
        }
        
        if (needGround) {
            result.ground = scanGround(dim, loc);
        }
        
        if (needObstacle && moveDir) {
            const groundData = result.ground || scanGround(dim, loc);
            result.obstacle = scanObstacles(dim, loc, moveDir, groundData.block);
        }
        
        if (needGap && moveDir) {
            const groundData = result.ground || scanGround(dim, loc);
            result.gap = scanGaps(dim, loc, moveDir, groundData.block);
        }
        
        if (needVault) {
            const groundDist = result.ground ? result.ground.distance : 
                               scanGround(dim, loc).distance;
            result.vault = scanVault(dim, loc, rot, groundDist);
        }
        
        if (needWall) {
            result.wall = scanWalls(p);
        }
        
        if (needLedge) {
            result.ledge = scanLedge(p, loc, rot, dim, lenientLedge);
        }
        
        if (needLiquid) {
            const currentBlock = dim.getBlock(loc);
            result.liquid = currentBlock?.isLiquid || currentBlock?.isWaterlogged || false;
        }
        
        return result;
    },
    
    scanObstaclesOnly: (p, tick) => {
        const moveDir = getMovementDirection(p);
        const groundData = scanGround(p.dimension, p.location);
        return scanObstacles(p.dimension, p.location, moveDir, groundData.block);
    },
    
    scanWalls: (p) => {
        return scanWalls(p);
    },
    
    clear: () => {}
};