import { world, system, ItemStack } from '@minecraft/server';
import Settings_ui from '../ui/settings_ui.js';
import { SettingsManager } from '../managers/settings_manager.js';

class Settings_controller {
    constructor() {
        this.settings_item_id = 's7d_parkour:settings';
        this.last_use = new Map();
        this.pending_grants = new Map();
        this.initialized = false;
        
        system.runTimeout(() => {
            this.initialize_event_listeners();
        }, 1);
    }

    initialize_event_listeners() {
        if (this.initialized) return;
        
        try {
            if (!world.afterEvents) {
                system.runTimeout(() => {
                    this.initialize_event_listeners();
                }, 10);
                return;
            }

            world.afterEvents.itemUse.subscribe((event) => {
                const player = event.source;
                const item = event.itemStack;
                if (item.typeId === this.settings_item_id) this.handle_settings_item_use(player);
            });

            world.afterEvents.itemUseOn.subscribe((event) => {
                const player = event.source;
                const item = event.itemStack;
                if (item.typeId === this.settings_item_id) {
                    event.cancel = true;
                    this.handle_settings_item_use(player);
                }
            });

            world.afterEvents.playerSpawn.subscribe((event) => {
                const player = event.player;
                const name = player.name;
                if (event.initialSpawn && !this.has_player_ever_received_item(name) && !this.pending_grants.has(name)) {
                    this.pending_grants.set(name, true);
                    system.runTimeout(() => {
                        if (!this.has_player_ever_received_item(name) && !this.player_has_settings_item(player)) {
                            this.give_settings_item(player);
                            this.mark_player_as_received(name);
                        }
                        this.pending_grants.delete(name);
                    }, 20);
                }
            });

            this.initialized = true;
        } catch (error) {
            system.runTimeout(() => {
                this.initialize_event_listeners();
            }, 20);
        }
    }

    player_has_settings_item(player) {
        try {
            const inventory = player.getComponent('minecraft:inventory');
            if (!inventory) return false;
            
            const container = inventory.container;
            if (!container) return false;
            
            for (let i = 0; i < container.size; i++) {
                const item = container.getItem(i);
                if (item && item.typeId === this.settings_item_id) {
                    return true;
                }
            }
            return false;
        } catch (error) {
            return false;
        }
    }

    has_player_ever_received_item(player_name) {
        try {
            return world.getDynamicProperty(`s7d_parkour:received_${player_name}`) === true;
        } catch (error) {
            return false;
        }
    }

    mark_player_as_received(player_name) {
        try {
            world.setDynamicProperty(`s7d_parkour:received_${player_name}`, true);
        } catch (error) {
        }
    }

    handle_settings_item_use(player) {
        const now = system.currentTick;
        const last = this.last_use.get(player.name) || 0;
        if (now - last < 10) return;
        this.last_use.set(player.name, now);
        Settings_ui.show_main_menu(player);
    }

    give_settings_item(player) {
        try {
            const inventory = player.getComponent('minecraft:inventory');
            if (!inventory) return;
            
            const container = inventory.container;
            if (!container) return;
            
            const item = new ItemStack(this.settings_item_id, 1);
            container.addItem(item);
        } catch (error) {
        }
    }
}

export default new Settings_controller();