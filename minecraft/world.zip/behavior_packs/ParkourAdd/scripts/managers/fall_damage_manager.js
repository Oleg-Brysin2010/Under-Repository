import { world, system } from '@minecraft/server';

class FallDamageManager {
    constructor() {
        this.protections = new Map();
        this.timerId = null;
        this.enabled = true;
        
        world.afterEvents.playerLeave?.subscribe(e => this.cleanup(e.playerName));
        system.runInterval(() => this.validate(), 20);
    }

    requestProtection(source, duration) {
        this.protections.set(source, system.currentTick + duration);
        this.update();
    }

    cancelProtection(source) {
        this.protections.delete(source);
        this.update();
    }

    cleanup(playerName) {
        for (const key of this.protections.keys()) {
            if (key.includes(playerName)) this.protections.delete(key);
        }
        this.update();
    }

    validate() {
        const tick = system.currentTick;
        const players = new Set(world.getPlayers().map(p => p.name));
        
        for (const [key, until] of this.protections) {
            const player = key.split('_')[0];
            if (!players.has(player) || until <= tick) {
                this.protections.delete(key);
            }
        }
        
        if (this.protections.size === 0 && !this.enabled) {
            this.setFallDamage(true);
        }
    }

    update() {
        if (this.timerId) {
            system.clearRun(this.timerId);
            this.timerId = null;
        }
        
        const tick = system.currentTick;
        const max = Math.max(...this.protections.values(), 0);
        
        if (max > tick) {
            this.setFallDamage(false);
            this.timerId = system.runTimeout(() => this.update(), Math.min(max - tick, 100));
        } else {
            this.setFallDamage(true);
        }
    }

    setFallDamage(enable) {
        if (this.enabled !== enable) {
            this.enabled = enable;
            try {
                world.getDimension('overworld').runCommand(`gamerule falldamage ${enable}`);
            } catch {}
        }
    }
}

export const GlobalFallDamage = new FallDamageManager();