import { world, system } from '@minecraft/server';

const states = new Map();

const createState = () => ({
    slide: { sliding: false, distance: 0, last: 0, info: null, endTime: 0 },
    roll: { rolling: false, air: false, inputReceived: false, fallY: 0, maxY: 0, last: 0, inputTime: null, gliding: false },
    vault: { vaulting: false, last: 0, info: null },
    wall_run: { running: false, side: null, start: 0, last: 0, lastJump: null, info: null },
    crawl: { crawling: false, start: 0, last: 0, info: null }
});

export const StateManager = {
    get: name => states.get(name) || (states.set(name, createState()), states.get(name)),
    
    clear: name => states.delete(name),
    
    set: (name, move, data) => {
        const state = StateManager.get(name);
        if (state && state[move]) {
            Object.assign(state[move], data);
        }
    },
    
    setInfo: (name, move, info) => {
        const state = StateManager.get(name);
        if (state && state[move]) {
            state[move].info = info;
        }
    },
    
    clearInfo: (name, move, time = system.currentTick) => {
        const state = StateManager.get(name);
        if (state && state[move]) {
            state[move].info = null;
            state[move].last = time;
        }
    }
};

world.afterEvents.playerSpawn.subscribe(e => {
    if (!states.has(e.player.name)) StateManager.get(e.player.name);
});

world.afterEvents.playerLeave.subscribe(e => {
    states.delete(e.playerName);
});