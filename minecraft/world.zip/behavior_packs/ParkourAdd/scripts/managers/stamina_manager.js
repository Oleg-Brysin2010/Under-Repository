import { world, system, EntityComponentTypes, EquipmentSlot } from '@minecraft/server';

const data = new Map();
const upgradeData = new Map();
const watchTracker = new Map();

const MAX = 100;
const REGEN_DELAY = 20;
const REGEN_AMOUNT = 1;
const MAX_UPGRADE_LEVEL = 6;

const COSTS = {
    roll: 20, slide_start: 1, slide_drain: 2, crawl: 6,
    wall_run_start: 1, wall_run_drain: 2, wall_run_jump: 10,
    vault: 15
};

const REDUCTIONS = {
    roll: 0.5, slide_drain: 0.1, crawl: 0.2,
    wall_run_drain: 0.1, wall_run_jump: 0.2, vault: 0.2
};

const MINS = {
    roll: 10, slide_start: 1, slide_drain: 1, crawl: 2,
    wall_run_start: 1, wall_run_drain: 0.5, wall_run_jump: 5,
    vault: 10
};

const MOVE_NAMES = {
    roll: 'Roll', slide: 'Slide', crawl: 'Crawl',
    wall_run: 'Wall Run', vault: 'Vault'
};

const createData = () => ({
    stamina: MAX, draining: false, drainRate: 0, moveType: null,
    lastMoveEnd: 0, nextRegen: null, sleeping: false, isDead: false
});

const createUpgradeData = () => ({
    moveUpgrades: Object.fromEntries(Object.keys(MOVE_NAMES).map(k => [k, 0])),
    regenLevel: 0, lastLevel: 0, upgradeHistory: []
});

const getRegenInterval = level => {
    const intervals = [10, 8, 6, 4, 2, 1];
    return intervals[Math.min(level, intervals.length - 1)] || 10;
};

const getAdjustedCost = (p, base, type) => {
    const upgrades = upgradeData.get(p.name);
    if (!upgrades) return base;
    
    const moveKey = type.replace(/_start|_drain|_hold|_jump/, '');
    const level = upgrades.moveUpgrades[moveKey] || 0;
    const reduction = (REDUCTIONS[type] || 0) * level;
    return Math.max(MINS[type] || 0, base - reduction);
};

const getRandomAvailableUpgrade = p => {
    const upgrades = upgradeData.get(p.name);
    if (!upgrades) return null;
    
    const movesNotMaxed = Object.keys(MOVE_NAMES).filter(m => upgrades.moveUpgrades[m] < MAX_UPGRADE_LEVEL);
    const options = [
        ...movesNotMaxed,
        ...(upgrades.regenLevel < MAX_UPGRADE_LEVEL ? ['regen'] : [])
    ];
    
    return options.length ? options[Math.floor(Math.random() * options.length)] : null;
};

const processLevelChanges = (p, oldLevel, newLevel, isDead) => {
    const upgrades = upgradeData.get(p.name);
    if (!upgrades) return;
    
    const levelDiff = newLevel - oldLevel;
    const changes = new Map();
    
    const processUpgrade = (isUpgrade) => {
        const iterations = Math.abs(levelDiff);
        for (let i = 0; i < iterations && (isUpgrade || upgrades.upgradeHistory.length > 0); i++) {
            if (isUpgrade) {
                const upgrade = getRandomAvailableUpgrade(p);
                if (!upgrade) break;
                
                if (upgrade === 'regen') {
                    upgrades.regenLevel = Math.min(MAX_UPGRADE_LEVEL, upgrades.regenLevel + 1);
                    changes.set('regen', upgrades.regenLevel);
                    upgrades.upgradeHistory.push({ type: 'regen', level: upgrades.regenLevel });
                } else {
                    upgrades.moveUpgrades[upgrade]++;
                    changes.set(upgrade, upgrades.moveUpgrades[upgrade]);
                    upgrades.upgradeHistory.push({ type: upgrade, level: upgrades.moveUpgrades[upgrade] });
                }
            } else {
                const last = upgrades.upgradeHistory.pop();
                if (!last) break;
                
                if (last.type === 'regen') {
                    upgrades.regenLevel = Math.max(0, upgrades.regenLevel - 1);
                    if (!isDead) changes.set('regen', upgrades.regenLevel);
                } else {
                    upgrades.moveUpgrades[last.type] = Math.max(0, upgrades.moveUpgrades[last.type] - 1);
                    if (!isDead) changes.set(last.type, upgrades.moveUpgrades[last.type]);
                }
            }
        }
    };
    
    if (levelDiff > 0) processUpgrade(true);
    else if (levelDiff < 0) processUpgrade(false);
    
    if (levelDiff > 0 || (levelDiff < 0 && !isDead)) {
        const isUpgrade = levelDiff > 0;
        changes.forEach((level, type) => {
            if (type === 'regen') {
                const color = isUpgrade ? '§e§l' : '§c§l';
                const desc = isUpgrade ? (level === 1 ? 'Unlocked!' : 'Faster regeneration') : 'Downgraded';
                p.sendMessage(`${color}Stamina §r§f§l${'●'.repeat(level) + '○'.repeat(MAX_UPGRADE_LEVEL - level)} §r§7§l- ${desc}`);
            } else {
                const name = MOVE_NAMES[type];
                const color = isUpgrade ? '§a§l' : '§c§l';
                const desc = isUpgrade ? 'Reduced stamina use' : 'Downgraded';
                p.sendMessage(`${color}${name} §r§f§l${'●'.repeat(level) + '○'.repeat(MAX_UPGRADE_LEVEL - level)} §r§7§l- ${desc}`);
            }
        });
    }
    
    upgrades.lastLevel = newLevel;
    p.setDynamicProperty('s7d_parkour:upgrades', JSON.stringify(upgrades));
};

export const StaminaManager = {
    init: p => {
        const saved = p.getDynamicProperty('s7d_parkour:stamina');
        const d = createData();
        d.stamina = saved !== undefined ? Math.max(0, Math.min(MAX, saved)) : MAX;
        data.set(p.name, d);
        
        let upgrades;
        try {
            const savedUpgrades = p.getDynamicProperty('s7d_parkour:upgrades');
            upgrades = savedUpgrades ? JSON.parse(savedUpgrades) : createUpgradeData();
        } catch {
            upgrades = createUpgradeData();
        }
        
        const currentLevel = p.level || 0;
        upgrades.lastLevel = currentLevel;
        
        if (currentLevel === 0) {
            upgrades = createUpgradeData();
            upgrades.lastLevel = 0;
            p.setDynamicProperty('s7d_parkour:upgrades', JSON.stringify(upgrades));
        }
        
        upgradeData.set(p.name, upgrades);
    },
    
    get: p => {
        const d = data.get(p.name);
        if (!d) return MAX;
        return Math.max(0, d.stamina);
    },
    
    set: (p, val) => {
        const clamped = Math.max(0, Math.min(MAX, val));
        if (!data.has(p.name)) data.set(p.name, createData());
        data.get(p.name).stamina = clamped;
        p.setDynamicProperty('s7d_parkour:stamina', clamped);
    },
    
    has: (p, required, type) => {
        const cost = getAdjustedCost(p, required, type);
        return StaminaManager.get(p) >= cost;
    },
    
    consume: (p, amount, type = 'instant') => {
        const cost = getAdjustedCost(p, amount, type);
        const current = StaminaManager.get(p);
        
        if (current < cost) return false;
        
        StaminaManager.set(p, current - cost);
        
        const instantMoves = ['instant', 'roll', 'crawl', 'vault', 'wall_run_jump'];
        if (instantMoves.includes(type)) {
            if (!data.has(p.name)) data.set(p.name, createData());
            data.get(p.name).lastMoveEnd = system.currentTick;
        }
        
        return true;
    },
    
    startDrain: (p, rate, type) => {
        if (StaminaManager.get(p) <= 0) return false;
        
        const d = data.get(p.name);
        if (d) {
            d.draining = true;
            d.drainRate = rate;
            d.moveType = type;
        }
        return true;
    },
    
    stopDrain: p => {
        const d = data.get(p.name);
        if (d) {
            d.lastMoveEnd = system.currentTick;
            d.draining = false;
            d.drainRate = 0;
            d.moveType = null;
            d.nextRegen = null;
        }
    },
    
    setDeathState: (p, isDead) => {
        const d = data.get(p.name);
        if (d) {
            d.isDead = isDead;
            if (isDead) StaminaManager.stopDrain(p);
        }
    },
    
    clear: name => {
        data.delete(name);
        upgradeData.delete(name);
    },
    
    reset: p => StaminaManager.set(p, MAX)
};

world.afterEvents.entityDie.subscribe(e => {
    if (e.deadEntity.typeId === 'minecraft:player') {
        StaminaManager.stopDrain(e.deadEntity);
        StaminaManager.setDeathState(e.deadEntity, true);
    }
});

world.afterEvents.playerSpawn.subscribe(e => {
    if (e.initialSpawn) {
        StaminaManager.init(e.player);
    } else {
        StaminaManager.setDeathState(e.player, false);
        StaminaManager.reset(e.player);
    }
});

system.runInterval(() => {
    for (const p of world.getPlayers()) {
        const d = data.get(p.name);
        if (!d) continue;
        
        const currentLevel = p.level || 0;
        const upgrades = upgradeData.get(p.name);
        if (upgrades?.lastLevel !== currentLevel) {
            processLevelChanges(p, upgrades.lastLevel, currentLevel, d.isDead);
        }
        
        if (d.isDead) {
            p.onScreenDisplay.setTitle(`stamina:${Math.round(StaminaManager.get(p))}`);
            continue;
        }
        
        let { stamina } = d;
        
        try {
            d.sleeping = p.isSleeping;
        } catch {
            d.sleeping = false;
        }
        
        if (d.draining && stamina > 0) {
            const drainCost = getAdjustedCost(p, d.drainRate, d.moveType + '_drain');
            const newStamina = Math.max(0, stamina - drainCost);
            StaminaManager.set(p, newStamina);
            
            if (newStamina <= 0) {
                StaminaManager.stopDrain(p);
            }
        }
        
        if (!d.draining && stamina < MAX) {
            const timeSinceMove = system.currentTick - (d.lastMoveEnd || 0);
            
            if (timeSinceMove >= REGEN_DELAY) {
                if (!d.nextRegen) d.nextRegen = system.currentTick;
                
                if (system.currentTick >= d.nextRegen) {
                    StaminaManager.set(p, Math.min(MAX, StaminaManager.get(p) + REGEN_AMOUNT));
                    
                    const regenLevel = upgrades?.regenLevel || 0;
                    const interval = d.sleeping ? 1 : getRegenInterval(regenLevel);
                    d.nextRegen = system.currentTick + interval;
                }
            } else {
                d.nextRegen = null;
            }
        }
        
        p.onScreenDisplay.setTitle(`stamina:${Math.round(StaminaManager.get(p))}`);
    }
}, 1);