import { world, system, EntityComponentTypes, EquipmentSlot } from '@minecraft/server';
import { StaminaManager } from './stamina_manager.js';

const upgradeData = new Map();
const watchTracker = new Map();

const MAX_SKILL_LEVEL = 18;

const MOVE_NAMES = {
    roll: 'Roll', slide: 'Slide', crawl: 'Crawl',
    wall_run: 'Wall Run', vault: 'Vault',
    aquadash: 'Aqua Dash', dropkick: 'Dropkick',
    ledge_grab: 'Ledge Grab', dodge: 'Dodge'
};

const createUpgradeData = () => ({
    unlockedMoves: [],
    lastLevel: 0,
    upgradeHistory: []
});

const getRandomAvailableMove = p => {
    const upgrades = upgradeData.get(p.name);
    if (!upgrades) return null;
    
    const lockedMoves = Object.keys(MOVE_NAMES).filter(m => !upgrades.unlockedMoves.includes(m));
    return lockedMoves.length ? lockedMoves[Math.floor(Math.random() * lockedMoves.length)] : null;
};

const updateWatchLevels = (p, upgrades) => {
    if (!upgrades) return;
    
    Object.keys(MOVE_NAMES).forEach(move => {
        const hasSkill = upgrades.unlockedMoves.includes(move) ? 0 : 1;
        p.playAnimation(`animation.s7d_parkour.${move}_skill_${hasSkill}`, { 
            controller: `s7d:${move}_skill`, blendOutTime: 0.05 
        });
    });
};

const processLevelChanges = (p, oldLevel, newLevel) => {
    const upgrades = upgradeData.get(p.name);
    if (!upgrades) return;
    
    const oldSkillLevel = Math.min(Math.floor(oldLevel / 2), MAX_SKILL_LEVEL);
    const newSkillLevel = Math.min(Math.floor(newLevel / 2), MAX_SKILL_LEVEL);
    const skillLevelDiff = newSkillLevel - oldSkillLevel;
    
    const changes = [];
    
    if (skillLevelDiff > 0 && newSkillLevel > 0) {
        for (let i = 0; i < skillLevelDiff; i++) {
            const move = getRandomAvailableMove(p);
            if (!move) break;
            
            upgrades.unlockedMoves.push(move);
            upgrades.upgradeHistory.push({ type: move, unlocked: true });
            changes.push({ move, unlocked: true });
        }
    } else if (skillLevelDiff < 0) {
        const levelsToRemove = Math.min(Math.abs(skillLevelDiff), upgrades.upgradeHistory.length);
        
        for (let i = 0; i < levelsToRemove; i++) {
            const last = upgrades.upgradeHistory.pop();
            if (!last) break;
            
            const idx = upgrades.unlockedMoves.indexOf(last.type);
            if (idx > -1) {
                upgrades.unlockedMoves.splice(idx, 1);
                changes.push({ move: last.type, unlocked: false });
            }
        }
    }
    
    upgrades.lastLevel = newLevel;
    p.setDynamicProperty('s7d_parkour:skill_upgrades', JSON.stringify(upgrades));
    updateWatchLevels(p, upgrades);
    
    if (changes.length > 0) {
        changes.forEach(({ move, unlocked }) => {
            const name = MOVE_NAMES[move];
            const color = unlocked ? '§6' : '§c';
            const desc = unlocked ? 'Skill Unlocked!' : 'Skill Lost!';
            p.sendMessage(`${color}${name} §r§7- ${desc}`);
        });
    }
};

export const SkillManager = {
    init: p => {
        let upgrades;
        const currentLevel = p.level || 0;
        
        try {
            const savedUpgrades = p.getDynamicProperty('s7d_parkour:skill_upgrades');
            if (savedUpgrades) {
                upgrades = JSON.parse(savedUpgrades);
                if (!upgrades.unlockedMoves) upgrades.unlockedMoves = [];
                if (!upgrades.upgradeHistory) upgrades.upgradeHistory = [];
            } else {
                upgrades = createUpgradeData();
            }
        } catch { 
            upgrades = createUpgradeData();
        }
        
        upgrades.unlockedMoves = Object.keys(MOVE_NAMES);
        upgrades.lastLevel = currentLevel;
        upgradeData.set(p.name, upgrades);
        p.setDynamicProperty('s7d_parkour:skill_upgrades', JSON.stringify(upgrades));
        updateWatchLevels(p, upgrades);
    },
    
    isUnlocked: (p, move) => {
        return true;
    },
    
    clear: name => [upgradeData].forEach(map => map.delete(name))
};

world.afterEvents.playerLeave.subscribe(e => {
    [watchTracker, upgradeData].forEach(map => map.delete(e.playerName));
});

system.runInterval(() => {
    for (const p of world.getPlayers()) {
        let upgrades = upgradeData.get(p.name);
        
        if (!upgrades) {
            SkillManager.init(p);
            upgrades = upgradeData.get(p.name);
        }
        
        let watchData = watchTracker.get(p.name);
        if (!watchData) {
            watchData = { hasWatch: false, lastLevelsUpdate: 0 };
            watchTracker.set(p.name, watchData);
        }
        
        const equippable = p.getComponent(EntityComponentTypes.Equippable);
        const hasWatch = equippable && [EquipmentSlot.Mainhand, EquipmentSlot.Offhand]
            .some(slot => equippable.getEquipment(slot)?.typeId === 's7d_parkour:smart_watch');
        
        if (hasWatch !== watchData.hasWatch) {
            watchData.hasWatch = hasWatch;
            if (hasWatch && upgrades) {
                updateWatchLevels(p, upgrades);
            }
        }
        
        if (hasWatch && system.currentTick - watchData.lastLevelsUpdate > 100 && upgrades) {
            updateWatchLevels(p, upgrades);
            watchData.lastLevelsUpdate = system.currentTick;
        }
    }
}, 1);