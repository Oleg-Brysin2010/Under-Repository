import { world, system } from '@minecraft/server';

const settings = new Map();

const DEFAULT_SETTINGS = {
    slide: { enabled: true },
    roll: { enabled: true },
    vault: { enabled: true },
    wall_run: { enabled: true },
    crawl: { enabled: true }
};

const MOVES = Object.keys(DEFAULT_SETTINGS);

const createDefaultSettings = () => {
    return {
        slide: { enabled: true },
        roll: { enabled: true },
        vault: { enabled: true },
        wall_run: { enabled: true },
        crawl: { enabled: true }
    };
};

export const SettingsManager = {
    load: name => {
        try {
            const saved = world.getDynamicProperty(`s7d_parkour:settings_${name}`);
            const parsed = saved ? JSON.parse(saved) : createDefaultSettings();
            settings.set(name, parsed);
        } catch {
            settings.set(name, createDefaultSettings());
        }
    },
    
    save: name => {
        try {
            const s = settings.get(name);
            if (s) {
                world.setDynamicProperty(`s7d_parkour:settings_${name}`, JSON.stringify(s));
            }
        } catch {}
    },
    
    get: name => {
        if (!settings.has(name)) SettingsManager.load(name);
        return settings.get(name);
    },
    
    enabled: (name, move) => {
        const s = SettingsManager.get(name);
        return s[move]?.enabled ?? true;
    },
    
    isLocked: (name, move) => {
        const s = SettingsManager.get(name);
        return s[move]?.locked ?? false;
    },
    
    toggle: (name, move) => {
        const s = SettingsManager.get(name);
        if (s[move] && !s[move].locked) {
            s[move].enabled = !s[move].enabled;
            SettingsManager.save(name);
            return s[move].enabled;
        }
        return false;
    },
    
    enable: (name, move) => {
        const s = SettingsManager.get(name);
        if (s[move]) {
            s[move].enabled = true;
            SettingsManager.save(name);
            return true;
        }
        return false;
    },
    
    disable: (name, move) => {
        const s = SettingsManager.get(name);
        if (s[move]) {
            s[move].enabled = false;
            SettingsManager.save(name);
            return true;
        }
        return false;
    },
    
    getAll: () => [...MOVES],
    
    getEnabled: name => {
        const s = SettingsManager.get(name);
        return MOVES.filter(move => s[move]?.enabled);
    },
    
    getDisabled: name => {
        const s = SettingsManager.get(name);
        return MOVES.filter(move => !s[move]?.enabled);
    },
    
    getStatus: name => {
        const s = SettingsManager.get(name);
        const status = {};
        for (const move of MOVES) {
            status[move] = {
                enabled: s[move]?.enabled ?? true,
                locked: s[move]?.locked ?? false
            };
        }
        return status;
    },
    
    clear: name => {
        settings.delete(name);
    }
};

world.afterEvents.playerSpawn.subscribe(e => {
    if (!settings.has(e.player.name)) {
        SettingsManager.load(e.player.name);
    }
});

world.afterEvents.playerLeave.subscribe(e => {
    SettingsManager.save(e.playerName);
    SettingsManager.clear(e.playerName);
});