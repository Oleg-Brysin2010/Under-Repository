import { ModalFormData } from '@minecraft/server-ui';
import { SettingsManager } from '../managers/settings_manager.js';
import { system } from '@minecraft/server';

class Settings_ui {
    constructor() {
        this.current_menus = new Map();
        this.MOVE_NAMES = {
            slide: "Slide",
            crawl: "Crawl",
            roll: "Roll",
            vault: "Vault",
            wall_run: "Wall Run",
            aquadash: "Aqua Dash",
            dropkick: "Dropkick",
            ledge_grab: "Ledge Grab",
            dodge: "Dodge"
        };
        this.LOCKED_MOVES = ['aquadash', 'dropkick', 'ledge_grab', 'dodge'];
    }

    async show_main_menu(player) {
        if (this.current_menus.has(player.name)) return;
        this.current_menus.set(player.name, true);

        try {
            const settings = SettingsManager.getStatus(player.name);
            const moves = SettingsManager.getAll();

            const form = new ModalFormData();
            form.title("§8Parkour Settings");
            
            const organized_moves = this.organized_moves_flat(moves);

            organized_moves.forEach(move => {
                const isLocked = this.LOCKED_MOVES.includes(move);
                const status = settings[move];
                const moveName = this.MOVE_NAMES[move] || move;
                
                if (isLocked) {
                    form.toggle(`§f${moveName} §c(Only available in Parkour++)`, { defaultValue: false });
                } else {
                    form.toggle(`§f${moveName}`, { defaultValue: status.enabled });
                }
            });

            form.submitButton("§8Save Settings");
            
            const response = await form.show(player);
            
            if (response.canceled) {
                return;
            }
            
            if (response.formValues && Array.isArray(response.formValues)) {
                this.apply_switch_changes(player, response.formValues, organized_moves);
            }
            
        } catch (error) {
            console.error("Settings UI Error:", error);
            player.sendMessage("§cError opening settings menu. Using chat commands instead.");
            this.show_status_in_chat(player);
            player.sendMessage("§7Use chat to toggle: 'slide on/off', 'roll on/off', etc.");
        } finally {
            this.current_menus.delete(player.name);
        }
    }

    organized_moves_flat(moves) {
        const basic = ['slide', 'crawl', 'roll'];
        const advanced = ['vault', 'wall_run'];
        const locked = ['aquadash', 'dropkick', 'ledge_grab', 'dodge'];
        const out = [];
        
        [basic, advanced].forEach(group => {
            group.forEach(m => { 
                if (moves.includes(m)) out.push(m); 
            });
        });
        
        moves.forEach(m => {
            if (!out.includes(m) && !locked.includes(m)) out.push(m);
        });
        
        locked.forEach(m => out.push(m));
        
        return out;
    }

    apply_switch_changes(player, form_values, moves) {
        const changed = [];
        let formIndex = 0;
        
        moves.forEach((move) => {
            try {
                const isLocked = this.LOCKED_MOVES.includes(move);
                const new_state = form_values[formIndex];
                
                if (!isLocked) {
                    const current = SettingsManager.enabled(player.name, move);
                    const moveName = this.MOVE_NAMES[move] || move;
                    
                    if (new_state !== current) {
                        SettingsManager.toggle(player.name, move);
                        changed.push(`${moveName}: ${new_state ? "§aON" : "§cOFF"}`);
                    }
                }
                
                formIndex++;
            } catch (error) {
                console.warn(`Error processing toggle for move ${move}:`, error);
            }
        });
        
        if (changed.length > 0) {
            system.runTimeout(() => {
                changed.forEach(line => {
                    try {
                        player.sendMessage(line);
                    } catch (error) {
                        console.warn("Error sending message:", error);
                    }
                });
            }, 1);
        } else {
            system.runTimeout(() => {
                try {
                    player.sendMessage("§7No changes made");
                    } catch (error) {
                        console.warn("Error sending message:", error);
                    }
            }, 1);
        }
    }

    show_status_in_chat(player) {
        try {
            const settings = SettingsManager.getStatus(player.name);
            const enabled = SettingsManager.getEnabled(player.name);
            const disabled = SettingsManager.getDisabled(player.name);

            player.sendMessage("§8─────────────────");
            player.sendMessage("§8Movement Settings");
            player.sendMessage("§8─────────────────");

            if (enabled.length > 0) {
                const list = enabled.map(m => this.MOVE_NAMES[m] || m).join("§8, §a");
                player.sendMessage(`§aEnabled: §a${list}`);
            }

            if (disabled.length > 0) {
                const list = disabled.map(m => this.MOVE_NAMES[m] || m).join("§8, §8");
                player.sendMessage(`§8Disabled: §8${list}`);
            }

            const status_text =
                enabled.length === 0 ? "§cAll abilities disabled" :
                disabled.length === 0 ? "§aAll abilities enabled" :
                `§7${enabled.length}/${enabled.length + disabled.length} enabled`;

            player.sendMessage(`\n§8Status: ${status_text}`);
        } catch (error) {
            console.warn("Error showing status:", error);
            player.sendMessage("§cError displaying status");
        }
    }
}

export default new Settings_ui();