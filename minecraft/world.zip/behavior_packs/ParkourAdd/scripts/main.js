import { world, system, EquipmentSlot, ItemStack } from '@minecraft/server';
import { StateManager } from './managers/player_state_manager.js';
import { StaminaManager } from './managers/stamina_manager.js';
import { SkillManager } from './managers/skill_manager.js';
import { BlockScanner } from './utils/block_scanner.js';
import { SettingsManager } from './managers/settings_manager.js';

import './utils/settings_controller.js';

import { SlideHandler } from './handlers/slide_handler.js';
import { RollHandler } from './handlers/roll_handler.js';
import { VaultHandler } from './handlers/vault_handler.js';
import { WallRunHandler } from './handlers/wall_run_handler.js';
import { CrawlHandler } from './handlers/crawl_handler.js';

const handlerInstances = new Map();
const creativePlayers = new Set();
const prewarmPending = new Map();
const originalKnockback = new WeakMap();
const joinedPlayers = new Set();

const KNOCKBACK_RESIST = {
    "minecraft:netherite_helmet": 0.1,
    "minecraft:netherite_chestplate": 0.1,
    "minecraft:netherite_leggings": 0.1,
    "minecraft:netherite_boots": 0.1
};

const SETTINGS_ITEM_ID = "s7d_parkour:settings";
const JOINED_TAG = "s7d_parkour_joined";

const createHandlers = () => ({
    slide: new SlideHandler(),
    roll: new RollHandler(),
    vault: new VaultHandler(),
    wallRun: new WallRunHandler(),
    crawl: new CrawlHandler()
});

const checkCreativeMode = p => {
    try {
        const result = p.runCommand('testfor @s[m=c]');
        return result.successCount > 0;
    } catch {
        return false;
    }
};

const hasSettingsItem = p => {
    const inv = p.getComponent("minecraft:inventory");
    if (!inv?.container) return false;
    
    for (let i = 0; i < inv.container.size; i++) {
        const item = inv.container.getItem(i);
        if (item?.typeId === SETTINGS_ITEM_ID) return true;
    }
    return false;
};

const giveSettingsItem = p => {
    if (hasSettingsItem(p)) return;
    
    try {
        const settingsItem = new ItemStack(SETTINGS_ITEM_ID, 1);
        const inv = p.getComponent("minecraft:inventory");
        if (inv?.container) {
            inv.container.addItem(settingsItem);
        }
    } catch (e) {
        console.warn(`Failed to give settings item to ${p.name}:`, e);
    }
};

const isFirstJoin = p => {
    return !p.hasTag(JOINED_TAG);
};

const markAsJoined = p => {
    if (!p.hasTag(JOINED_TAG)) {
        p.addTag(JOINED_TAG);
    }
};

const getKnockbackCompensation = p => {
    const equip = p.getComponent("minecraft:equippable");
    if (!equip) return 1;

    let resistance = 0;
    
    const helmet = equip.getEquipment(EquipmentSlot.Head);
    if (helmet && KNOCKBACK_RESIST[helmet.typeId]) {
        resistance += KNOCKBACK_RESIST[helmet.typeId];
    }
    
    const chest = equip.getEquipment(EquipmentSlot.Chest);
    if (chest && KNOCKBACK_RESIST[chest.typeId]) {
        resistance += KNOCKBACK_RESIST[chest.typeId];
    }
    
    const legs = equip.getEquipment(EquipmentSlot.Legs);
    if (legs && KNOCKBACK_RESIST[legs.typeId]) {
        resistance += KNOCKBACK_RESIST[legs.typeId];
    }
    
    const boots = equip.getEquipment(EquipmentSlot.Feet);
    if (boots && KNOCKBACK_RESIST[boots.typeId]) {
        resistance += KNOCKBACK_RESIST[boots.typeId];
    }

    resistance = Math.min(resistance, 0.4);
    
    if (resistance === 0) return 1;
    return 1 / (1 - resistance);
};

const patchPlayerKnockback = p => {
    if (originalKnockback.has(p)) return;
    
    const original = p.applyKnockback.bind(p);
    originalKnockback.set(p, original);
    
    p.applyKnockback = function(horizontal, vertical) {
        const compensation = getKnockbackCompensation(p);
        
        const compensatedHorizontal = {
            x: horizontal.x * compensation,
            z: horizontal.z * compensation
        };
        const compensatedVertical = vertical * compensation;
        
        return original(compensatedHorizontal, compensatedVertical);
    };
};

world.afterEvents.playerJoin.subscribe(e => {
    const p = e.playerName;
    prewarmPending.set(p, true);
    
    if (!joinedPlayers.has(p)) {
        joinedPlayers.add(p);
    }
});

world.afterEvents.playerSpawn.subscribe(e => {
    const p = e.player;
    
    if (!handlerInstances.has(p.name)) {
        handlerInstances.set(p.name, createHandlers());
    }
    
    patchPlayerKnockback(p);
    StaminaManager.init(p);
    SkillManager.init(p);
    
    if (isFirstJoin(p)) {
        system.runTimeout(() => {
            giveSettingsItem(p);
            markAsJoined(p);
        }, 20);
    }
    
    system.runTimeout(() => {
        p.sendMessage('§6§l⚠ §r§7This is the §efinal update §7for Parkour Add-On.');
        p.sendMessage('§6Parkour++ §7is coming to Marketplace soon!');
        p.sendMessage('§7Follow §fSE7ENDAYS Studio §7on TikTok for updates');
    }, 40);
});

world.afterEvents.playerLeave.subscribe(e => {
    const handlers = handlerInstances.get(e.playerName);
    if (handlers) {
        Object.values(handlers).forEach(handler => {
            if (handler && typeof handler.cleanup === 'function') {
                try {
                    handler.cleanup();
                } catch (error) {
                    console.warn(`Cleanup error for handler:`, error);
                }
            }
        });
    }
    handlerInstances.delete(e.playerName);
    creativePlayers.delete(e.playerName);
    StaminaManager.clear(e.playerName);
    SkillManager.clear(e.playerName);
    StateManager.clear(e.playerName);
    prewarmPending.delete(e.playerName);
    joinedPlayers.delete(e.playerName);
});

system.runInterval(() => {
    const currentTick = system.currentTick;
    
    for (const p of world.getPlayers()) {
        try {
            patchPlayerKnockback(p);
            
            if (prewarmPending.has(p.name)) {
                const vel = p.getVelocity();
                if (Math.abs(vel.x) > 0.01 || Math.abs(vel.z) > 0.01) {
                    prewarmPending.delete(p.name);
                    p.playAnimation('animation.s7d_parkour.humanoid.prewarm', { blendInTime: 0.2 });
                }
            }
            
            let handlers = handlerInstances.get(p.name);
            if (!handlers) {
                handlers = createHandlers();
                handlerInstances.set(p.name, handlers);
                StaminaManager.init(p);
                SkillManager.init(p);
            }
            
            if (checkCreativeMode(p)) {
                if (!creativePlayers.has(p.name)) {
                    creativePlayers.add(p.name);
                    p.sendMessage('§c§l✗ §r§7Parkour moves are §cdisabled §7in creative mode');
                }
                continue;
            } else {
                if (creativePlayers.has(p.name)) {
                    creativePlayers.delete(p.name);
                    p.sendMessage('§a§l✓ §r§7Parkour moves are now §aenabled');
                }
            }
            
            const state = StateManager.get(p.name);
            if (!state) continue;

            if (p.isOnGround && state.roll?.gliding) {
                if (handlers.roll && typeof handlers.roll.handle === 'function') {
                    handlers.roll.handle(p, currentTick); 
                }
            }

            if (SettingsManager.enabled(p.name, 'slide') && handlers.slide) {
                handlers.slide.handle(p, currentTick);
            }

            if (SettingsManager.enabled(p.name, 'roll') && handlers.roll) {
                handlers.roll.handle(p, currentTick); 
            }

            if (SettingsManager.enabled(p.name, 'vault') && handlers.vault) {
                handlers.vault.handle(p, currentTick);
            }

            if (SettingsManager.enabled(p.name, 'wall_run') && handlers.wallRun) {
                handlers.wallRun.handle(p, currentTick);
            }

            if (SettingsManager.enabled(p.name, 'crawl') && handlers.crawl) {
                handlers.crawl.handle(p, currentTick);
            }
        } catch (error) {
            console.warn(`Error processing player ${p.name}:`, error);
        }
    }
}, 1);