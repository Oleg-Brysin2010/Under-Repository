import { system, EquipmentSlot } from '@minecraft/server';
import { SkillManager } from '../managers/skill_manager.js';
import { StateManager } from '../managers/player_state_manager.js';
import { StaminaManager } from '../managers/stamina_manager.js';
import { SettingsManager } from '../managers/settings_manager.js';
import { BlockScanner } from '../utils/block_scanner.js';

export class VaultHandler {
    constructor() {
        this.timers = new Map();
        this.lastTick = new Map();
        this.mustTouch = new Set();
        this.lastVelocity = new Map();
    }

    getNetheriteArmorCount(p) {
        const equip = p.getComponent("minecraft:equippable");
        if (!equip) return 0;
        
        let count = 0;
        const slots = [
            { slot: EquipmentSlot.Head, id: "minecraft:netherite_helmet" },
            { slot: EquipmentSlot.Chest, id: "minecraft:netherite_chestplate" },
            { slot: EquipmentSlot.Legs, id: "minecraft:netherite_leggings" },
            { slot: EquipmentSlot.Feet, id: "minecraft:netherite_boots" }
        ];
        
        slots.forEach(({ slot, id }) => {
            const item = equip.getEquipment(slot);
            if (item && item.typeId === id) count++;
        });
        
        return count;
    }

    handle(p, tick) {
        if (this.lastTick.get(p.name) === tick) return;

        if (!SkillManager.isUnlocked(p, 'vault')) return;
        this.lastTick.set(p.name, tick);

        const state = StateManager.get(p.name);
        if (!state || !state.vault) return;
        const v = state.vault;
        
        const currentVel = p.getVelocity();
        this.lastVelocity.set(p.name, currentVel);
        
        if (this.mustTouch.has(p.name)) {
            if (p.isOnGround) {
                this.mustTouch.delete(p.name);
            } else return;
        }

        if (v.vaulting) {
            if (tick - v.start > 10) {
                this.end(p, tick, state);
            }
            p.fallDistance = 0;
            return;
        }

        if (!p.isSprinting || !p.isJumping || p.isOnGround) return;

        const climbing = p.isClimbing || state.climb?.climbing;
        const blocked = state.roll.rolling || state.roll.inputReceived || 
                       state.slide.sliding || climbing;

        if (blocked || !StaminaManager.has(p, 15, 'vault')) return;

        const scan = BlockScanner.scan(p, tick, {
            needVault: true,
            needGround: true,
            needLiquid: true
        });
        
        if (scan.liquid) return;
        
        if (!state.roll.inputReceived && !state.roll.rolling) {
            const allowVault = scan.vault.valid && 
                              scan.vault.distance <= 0.9 && 
                              (scan.ground.distance >= 1.5 || !scan.vault.high);
            
            if (!allowVault) return;

            if (!StaminaManager.consume(p, 15, 'vault')) return;

            Object.assign(v, {
                vaulting: true,
                start: tick,
                last: tick
            });

            StateManager.setInfo(p.name, 'vault', null);

            if (state.roll) {
                Object.assign(state.roll, { 
                    air: false, 
                    inputReceived: false, 
                    fallY: 0 
                });
            }

            p.playAnimation("animation.s7d_parkour.humanoid.vault", { blendOutTime: 0.2 });
            p.dimension.playSound("game.player.attack.strong", p.location, { pitch: 1.5, volume: 0.6 });
            
            let baseUpwardForce = 0.52;
            const fallCompensation = currentVel.y < 0 ? Math.abs(currentVel.y) * 0.6 : 0;
            
            const armorPieces = this.getNetheriteArmorCount(p);
            
            if (armorPieces > 0) {
                const resistance = armorPieces * 0.1;
                const expectedCompensation = 1 / (1 - resistance);
                baseUpwardForce = baseUpwardForce / (1 + (expectedCompensation - 1) * 0.4);
            }
            
            const totalUpwardForce = baseUpwardForce + fallCompensation;
            
            p.applyKnockback({ x: 0, z: 0 }, totalUpwardForce);
            
            this.mustTouch.add(p.name);
            p.fallDistance = 0;
        }
    }

    end(p, tick, state) {
        const v = state?.vault;
        if (!v) return;

        this.clearTimer(p.name);
        this.lastTick.delete(p.name);
        this.lastVelocity.delete(p.name);
        this.mustTouch.delete(p.name);

        v.vaulting = false;
        StateManager.clearInfo(p.name, 'vault', tick);
    }

    setTimer(key, callback, delay) {
        this.clearTimer(key);
        const id = system.runTimeout(() => {
            callback();
            this.timers.delete(key);
        }, delay);
        this.timers.set(key, id);
    }

    clearTimer(key) {
        const id = this.timers.get(key);
        if (id) {
            system.clearRun(id);
            this.timers.delete(key);
        }
    }

    cleanup() {
        [...this.timers.values()].forEach(id => system.clearRun(id));
        [this.timers, this.mustTouch, this.lastTick, this.lastVelocity].forEach(map => map.clear());
    }
}