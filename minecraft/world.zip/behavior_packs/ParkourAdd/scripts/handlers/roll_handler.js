import { world, system } from '@minecraft/server';
import { SkillManager } from '../managers/skill_manager.js';
import { StateManager } from '../managers/player_state_manager.js';
import { StaminaManager } from '../managers/stamina_manager.js';
import { BlockScanner } from '../utils/block_scanner.js';

export class RollHandler {
    constructor() {
        this.timers = new Map();
        this.lastTick = new Map();
        this.lastJump = new Map();
        this.activeStates = new Map();
        this.jumpHoldStart = new Map();
        this.fallDamageStates = new Map();
        this.jumpTaps = new Map();
        this.knockbackCanceled = new Map();
    }

    handle(p, tick) {
        if (this.lastTick.get(p.name) === tick) return;

        if (!SkillManager.isUnlocked(p, 'roll')) return;
        this.lastTick.set(p.name, tick);

        const state = StateManager.get(p.name);
        const r = state.roll;

        const scan = BlockScanner.scan(p, tick, { needLiquid: true });
        if (scan.liquid && r.rolling) return this.end(p, tick);

        this.checkInputTimeout(p, r, tick);
        this.handleFallDamageToggle(r, p);

        if (!p.isOnGround) {
            this.handleAir(p, r, tick);
        } else if (r.inputReceived) {
            this.handleLanding(p, r, tick);
        } else if (!r.rolling) {
            this.resetFall(r);
        }
    }

    checkInputTimeout(p, r, tick) {
        if (r.inputReceived && !r.rolling && r.inputTime !== undefined) {
            const elapsed = tick - r.inputTime;
            if (elapsed >= 20) {
                this.clearInputTimeout(p, r);
            } else if (!this.timers.has(p.name + '_input')) {
                this.setTimer(p.name + '_input', () => {
                    if (r.inputReceived && !r.rolling) this.clearInputTimeout(p, r);
                }, 20 - elapsed);
            }
        }
    }

    clearInputTimeout(p, r) {
        Object.assign(r, { inputReceived: false, inputTime: undefined });
        this.clearTimer(p.name + '_input');
        this.activeStates.set(p.name, false);
        this.setFallDamage(p, true);
        if (p.isOnGround) this.resetFall(r);
    }

    setFallDamage(p, enabled) {
        const currentState = this.fallDamageStates.get(p.name);
        if (currentState !== enabled) {
            p.dimension.runCommand(`gamerule falldamage ${enabled ? 'true' : 'false'}`);
            this.fallDamageStates.set(p.name, enabled);
        }
    }

    handleFallDamageToggle(r, p) {
        const active = r.inputReceived || r.rolling;
        const lastActive = this.activeStates.get(p.name) ?? false;
        
        if (active && !lastActive) {
            this.setFallDamage(p, false);
            this.activeStates.set(p.name, true);
        } else if (!active && lastActive) {
            this.activeStates.set(p.name, false);
        }
    }

    handleAir(p, r, tick) {
        if (!r.air) {
            Object.assign(r, { air: true, fallY: p.location.y, maxY: p.location.y, inputReceived: false, gliding: p.isGliding });
        }

        if (p.location.y > r.maxY) r.maxY = p.location.y;

        const fallHeight = r.maxY - p.location.y;
        const state = StateManager.get(p.name);
        const afterSpecial = (state.wall_run.last && tick - state.wall_run.last < 40);
        const validHeight = afterSpecial ? fallHeight >= 2 : fallHeight >= 3;

        const jumping = p.isJumping;
        const lastJump = this.lastJump.get(p.name) || false;
        const jumpPressed = jumping && !lastJump;

        if (jumpPressed) this.jumpTaps.set(p.name, tick);

        const lastTap = this.jumpTaps.get(p.name);
        const hasValidTap = lastTap && (tick - lastTap) <= 3;

        if (r.gliding || p.isGliding) {
            if (jumping && !lastJump) {
                this.jumpHoldStart.set(p.name, tick);
            } else if (!jumping && lastJump) {
                this.jumpHoldStart.delete(p.name);
            }
        }

        this.lastJump.set(p.name, jumping);

        const scan = BlockScanner.scan(p, tick, {
            needGround: true,
            needGap: true
        });

        const groundDistance = scan.ground.distance;
        const hasLandingSpot = scan.gap.high || (groundDistance > 0.1 && groundDistance <= 1.5);

        if (!r.rolling && !r.inputReceived && hasLandingSpot && StaminaManager.has(p, 20, 'roll')) {
            this.clearTimer(p.name + '_input');
            
            if (p.isGliding && jumping && this.jumpHoldStart.has(p.name)) {
                Object.assign(r, { inputReceived: true, fallY: p.location.y, inputTime: tick });
                this.setFallDamage(p, false);
            } else if (!p.isGliding && hasValidTap && validHeight) {
                this.jumpTaps.delete(p.name);
                Object.assign(r, { inputReceived: true, fallY: p.location.y, inputTime: tick });
                this.setFallDamage(p, false);
            }
        }

        if (p.isGliding) r.gliding = true;
    }

    handleLanding(p, r, tick) {
        const scan = BlockScanner.scan(p, tick, { needLiquid: true, needGround: true });
        if (scan.liquid) {
            this.setFallDamage(p, true);
            this.clearInputTimeout(p, r);
            return;
        }

        if (!r.rolling && scan.ground.block) {
            this.start(p, tick);
            r.inputReceived = false;
        }
    }

    start(p, tick) {
        const r = StateManager.get(p.name).roll;
        if (!StaminaManager.consume(p, 20, 'roll')) {
            r.inputReceived = false;
            this.setFallDamage(p, true);
            this.resetFall(r);
            return;
        }

        this.resetFall(r);
        Object.assign(r, { rolling: true, start: tick, lastUpdate: tick });
        this.clearTimer(p.name + '_input');
        this.knockbackCanceled.set(p.name, false);

        p.playAnimation("animation.s7d_parkour.humanoid.roll", { blendOutTime: 0.3 });
        p.inputPermissions.jumpEnabled = false;
        p.dimension.spawnParticle("s7d_parkour:drop", p.location);
        p.dimension.playSound("damage.fallsmall", p.location, { volume: 0.6, pitch: 0.8 });

        StateManager.setInfo(p.name, 'roll', tick);
        this.startKnockback(p);
        this.setTimer(p.name + '_roll', () => this.end(p, tick), 14);
    }

    startKnockback(p) {
        this.clearTimer(p.name + '_kb');
        const power = 0.9;
        let tickCount = 0, lastScan = null;

        const id = system.runInterval(() => {
            const r = StateManager.get(p.name).roll;
            if (++tickCount >= 16 || !r.rolling || this.knockbackCanceled.get(p.name)) {
                system.clearRun(id);
                this.timers.delete(p.name + '_kb');
                return;
            }

            const yawRad = (p.getRotation().y + 90) * Math.PI / 180;
            const adjustedPower = power * (1 - tickCount / 15);
            const currentScan = BlockScanner.scan(p, system.currentTick, {
                needObstacle: true,
                needGap: true
            });

            if (currentScan.obstacle) {
                this.knockbackCanceled.set(p.name, true);
                system.clearRun(id);
                this.timers.delete(p.name + '_kb');
                return;
            }

            if (this.shouldTeleport(lastScan, currentScan)) {
                const kbX = Math.cos(yawRad) * adjustedPower, kbZ = Math.sin(yawRad) * adjustedPower;
                const newLoc = { x: p.location.x + kbX * 0.1, y: p.location.y + 0.1, z: p.location.z + kbZ * 0.1 };
                if (p.tryTeleport(newLoc)) p.teleport(newLoc);
            }

            p.applyKnockback({ x: Math.cos(yawRad) * adjustedPower, z: Math.sin(yawRad) * adjustedPower }, -0.12);
            lastScan = currentScan;
        });

        this.timers.set(p.name + '_kb', id);
    }

    shouldTeleport(lastScan, currentScan) {
        if (!lastScan || !currentScan) return false;
        const { gap: lastGap } = lastScan, { gap: currentGap } = currentScan;
        return (currentGap.high || currentGap.low) &&
               ((!lastGap.high && !lastGap.low) ||
                (lastGap.high && !lastGap.low && currentGap.low) ||
                (lastGap.low && !lastGap.high && currentGap.high));
    }

    end(p, tick) {
        const r = StateManager.get(p.name).roll;
        if (!r) return;

        ['_roll', '_kb', '_input'].forEach(suffix => this.clearTimer(p.name + suffix));
        Object.assign(r, { rolling: false, last: tick });

        p.inputPermissions.jumpEnabled = true;
        this.resetFall(r);
        StateManager.clearInfo(p.name, 'roll', tick);
        this.lastJump.set(p.name, false);
        this.jumpHoldStart.delete(p.name);
        this.knockbackCanceled.delete(p.name);

        this.setTimer(p.name + '_fallback', () => {
            const state = StateManager.get(p.name);
            if (!state?.roll?.rolling && !state?.roll?.inputReceived) {
                this.setFallDamage(p, true);
            }
        }, 10);
    }

    resetFall(r) {
        Object.assign(r, { air: false, inputReceived: false, fallY: 0, maxY: 0, inputTime: null, gliding: false });
    }

    setTimer(key, callback, delay) {
        this.clearTimer(key);
        this.timers.set(key, system.runTimeout(() => { callback(); this.timers.delete(key); }, delay));
    }

    clearTimer(key) {
        const id = this.timers.get(key);
        if (id) { system.clearRun(id); this.timers.delete(key); }
    }

    cleanup() {
        [...this.timers.values()].forEach(id => system.clearRun(id));
        [this.timers, this.jumpHoldStart, this.fallDamageStates, this.jumpTaps, this.knockbackCanceled].forEach(map => map.clear());
    }
}