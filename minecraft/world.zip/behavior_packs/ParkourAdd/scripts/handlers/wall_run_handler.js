import { system } from '@minecraft/server';
import { SkillManager } from '../managers/skill_manager.js';
import { StateManager } from '../managers/player_state_manager.js';
import { StaminaManager } from '../managers/stamina_manager.js';
import { BlockScanner } from '../utils/block_scanner.js';
import { GlobalFallDamage } from '../managers/fall_damage_manager.js';

export class WallRunHandler {
    constructor() {
        this.lastTick = new Map();
        this.mustTouchGroundPlayers = new Set();
        this.lastJumpState = new Map();
    }

    handle(p, tick) {
        if (this.lastTick.get(p.name) === tick) return;

        if (!SkillManager.isUnlocked(p, 'wall_run')) return;
        this.lastTick.set(p.name, tick);

        if (!StaminaManager.has(p, 0, 'wall_run')) return;

        const state = StateManager.get(p.name);
        if (!state || !state.wall_run) return;
        const w = state.wall_run;
        
        const vaulting = state.vault?.vaulting;

        if (this.mustTouchGroundPlayers.has(p.name)) {
            if (p.isOnGround) {
                this.mustTouchGroundPlayers.delete(p.name);
            } else return;
        }

        if (w.running) {
            if (vaulting) {
                this.end(p, tick, false, true);
                return;
            }
            
            const scan = BlockScanner.scan(p, tick, {
                needWall: true,
                needGround: true
            });
            
            this.handleActive(p, tick, state, w, scan.wall, scan.ground.distance);
            return;
        }

        if (!p.isSprinting || p.isOnGround) return;

        const climbing = p.isClimbing || state.climb?.climbing;
        const blocked = state.slide.sliding || 
                       state.roll.rolling || climbing || vaulting;

        if (blocked || p.isGliding || 
            !StaminaManager.has(p, 1, 'wall_run_start') ||
            (w.lastJump && (tick - w.lastJump) < 4) ||
            state.roll.inputReceived || state.roll.rolling) return;

        const scan = BlockScanner.scan(p, tick, {
            needWall: true,
            needGround: true,
            needVault: true,
            needLiquid: true
        });

        if (scan.liquid) return;

        const canStartWallRun = scan.wall.side || 
            (scan.wall.leftDistance <= 0.6 || scan.wall.rightDistance <= 0.6);
        
        if (!canStartWallRun) return;
        
        if (scan.ground.distance < 1.5) return;

        const vaultWouldBeValid = scan.vault.valid && 
                                  p.isJumping &&
                                  StaminaManager.has(p, 15, 'vault');
        
        if (vaultWouldBeValid) return;
        
        let startSide = scan.wall.side;
        if (!startSide) {
            startSide = scan.wall.leftDistance <= scan.wall.rightDistance ? "left" : "right";
        }
        
        if (!StaminaManager.consume(p, 1, 'wall_run_start')) return;
        
        this.start(p, tick, state, startSide);
    }

    handleActive(p, tick, state, w, wallScan, groundDistance) {
        const info = w.info;
        if (!info) return;

        const jumping = p.isJumping;
        const lastJump = this.lastJumpState.get(p.name) ?? false;

        const currentWallDistance = w.side === "left" ? wallScan.leftDistance : wallScan.rightDistance;

        const scan = BlockScanner.scan(p, tick, {
            needLiquid: true
        });

        if (p.isOnGround ||
            StaminaManager.get(p) <= 0 ||
            (tick - info.start) > 20 ||
            !p.isSprinting ||
            p.isGliding ||
            scan.liquid ||
            wallScan.side !== w.side ||
            currentWallDistance >= 1.0 ||
            groundDistance < 0.5) {
            this.end(p, tick, false);
            return;
        }

        if (jumping && !lastJump) {
            const oppositeDistance = w.side === "left" ? wallScan.rightDistance : wallScan.leftDistance;
            const canJump = oppositeDistance > 0.8;
            
            if (canJump) {
                this.performJump(p, tick, w);
                return;
            }
            p.dimension.playSound("game.player.attack.nodamage", p.location, { volume: 0.5, pitch: 0.8 });
        }
        this.lastJumpState.set(p.name, jumping);

        this.updateForces(p, tick, w);
        this.updateEffects(p, tick, w, info);
    }

    performJump(p, tick, w) {

        const yawRad = (p.getRotation().y + 90) * Math.PI / 180;
        const oppositeDirX = w.side === "left" ? Math.cos(yawRad + Math.PI / 2) : Math.cos(yawRad - Math.PI / 2);
        const oppositeDirZ = w.side === "left" ? Math.sin(yawRad + Math.PI / 2) : Math.sin(yawRad - Math.PI / 2);

        p.applyKnockback({
            x: Math.cos(yawRad) * 0.4 + oppositeDirX * 0.8,
            z: Math.sin(yawRad) * 0.4 + oppositeDirZ * 0.8
        }, 0.5);
        
        p.dimension.playSound("game.player.attack.strong", p.location, { volume: 0.8, pitch: 1.2 });
        p.dimension.spawnParticle("s7d_parkour:wallrun_dust", {
            x: p.location.x + oppositeDirX * 0.3,
            y: p.location.y + 1.1,
            z: p.location.z + oppositeDirZ * 0.3
        });

        w.lastJump = tick;
        this.end(p, tick, true);
    }

    start(p, tick, state, side) {
        StateManager.setInfo(p.name, 'wall_run', {
            start: tick,
            lastSound: 0, 
            lastParticle: 0, 
            lastFootParticle: 0
        });

        const w = state.wall_run;
        w.running = true;
        w.side = side;

        GlobalFallDamage.cancelProtection(`${p.name}_wallrun`);
        GlobalFallDamage.requestProtection(`${p.name}_wallrun`, 999999);

        const viewDir = p.getViewDirection();
        p.applyKnockback({ x: viewDir.x * 0.5, z: viewDir.z * 0.5 }, 0);
        
        const yawRad = (p.getRotation().y + 90) * Math.PI / 180;
        const wallDirX = side === "left" ? Math.cos(yawRad - Math.PI / 2) : Math.cos(yawRad + Math.PI / 2);
        const wallDirZ = side === "left" ? Math.sin(yawRad - Math.PI / 2) : Math.sin(yawRad + Math.PI / 2);
        
        p.applyKnockback({
            x: wallDirX * 0.15,
            z: wallDirZ * 0.15
        }, 0);
        
        p.playAnimation(`animation.s7d_parkour.humanoid.wallrun.${side}`, { blendOutTime: 0.1 });
        this.lastJumpState.set(p.name, p.isJumping);
        
        StaminaManager.startDrain(p, 2, 'wall_run');
    }

    updateForces(p, tick, w) {
        const yawRad = (p.getRotation().y + 90) * Math.PI / 180;
        p.applyKnockback({ x: Math.cos(yawRad) * 0.5, z: Math.sin(yawRad) * 0.5 }, -0.03);
    }

    updateEffects(p, tick, w, info) {
        const yawRad = (p.getRotation().y + 90) * Math.PI / 180;
        const sideDirX = w.side === "left" ? Math.cos(yawRad - Math.PI / 2) : Math.cos(yawRad + Math.PI / 2);
        const sideDirZ = w.side === "left" ? Math.sin(yawRad - Math.PI / 2) : Math.sin(yawRad + Math.PI / 2);

        if (tick - (info.lastParticle || 0) >= 1) {
            p.dimension.spawnParticle("s7d_parkour:wallrun_dust", {
                x: p.location.x + sideDirX * 0.3,
                y: p.location.y + 1.1,
                z: p.location.z + sideDirZ * 0.3
            });
            info.lastParticle = tick;
        }

        if (tick - (info.lastFootParticle || 0) >= 2) {
            p.dimension.spawnParticle("s7d_parkour:wallrun_foot_dust", {
                x: p.location.x + sideDirX * 0.3,
                y: p.location.y + 0.2,
                z: p.location.z + sideDirZ * 0.3
            });
            info.lastFootParticle = tick;
        }

        if (tick - info.lastSound >= 3) {
            const sound = "step.stone";
            const config = { pitch: 1.2, volume: 0.8 };
            p.dimension.playSound(sound, p.location, config);
            info.lastSound = tick;
        }
    }

    end(p, tick, isWallJump = false, isVaultStart = false) {
        const state = StateManager.get(p.name);
        if (!state) return;

        const w = state.wall_run;
        
        const skipEndAnimation = isVaultStart;
        
        if (w?.running && w?.side && !skipEndAnimation) {
            p.playAnimation(`animation.s7d_parkour.humanoid.wallrun.${w.side}.end`, { 
                blendOutTime: 0.2 
            });
        }

        this.lastJumpState.delete(p.name);
        
        if (!isWallJump) {
            this.mustTouchGroundPlayers.add(p.name);
        }

        GlobalFallDamage.cancelProtection(`${p.name}_wallrun`);
        GlobalFallDamage.requestProtection(`${p.name}_wallrun`, 10);

        if (w) {
            w.running = false;
            w.side = null;
            w.start = 0;
            w.last = tick;
        }

        if (state.roll) {
            Object.assign(state.roll, { 
                air: false, 
                validFallHeight: false, 
                inputReceived: false, 
                fallY: 0 
            });
        }

        StateManager.clearInfo(p.name, 'wall_run', tick);
        StaminaManager.stopDrain(p, 'wall_run');
    }

    cleanup() {
        [this.mustTouchGroundPlayers, this.lastJumpState, 
         this.lastTick].forEach(map => map.clear());
    }
}