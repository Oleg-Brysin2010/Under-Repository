import { MolangVariableMap, system } from '@minecraft/server';
import { SkillManager } from '../managers/skill_manager.js';
import { StateManager } from '../managers/player_state_manager.js';
import { StaminaManager } from '../managers/stamina_manager.js';
import { BlockScanner } from '../utils/block_scanner.js';

export class SlideHandler {
    constructor() {
        this.lastTick = new Map();
        this.lastScan = new Map();
        this.lastUpKnockback = new Map();
    }

    handle(p, tick) {
        if (this.lastTick.get(p.name) === tick) return;

        if (!SkillManager.isUnlocked(p, 'slide')) return;
        this.lastTick.set(p.name, tick);

        const state = StateManager.get(p.name);
        if (!state || !state.slide) return;
        const s = state.slide;
        
        this.updateSprint(p, tick, s);

        const qualified = s.distance >= 1.5 && 
            (s.endTime ? tick - s.endTime <= 1 : p.isSprinting);

        const canSlide = qualified && p.isOnGround && !state.roll.rolling;

        if (canSlide && p.isSneaking && !s.sliding && 
            StaminaManager.consume(p, 1, 'slide_start')) {
            
            const scan = BlockScanner.scan(p, tick, {
                needObstacle: true,
                needGap: true,
                needLiquid: true
            });
            if (scan.liquid || scan.obstacle || scan.gap.low) {
                return;
            }
            
            s.sliding = true;
            s.start = tick;
            
            const alt = Math.random() < 0.2;
            const anim = alt ? "animation.s7d_parkour.humanoid.slide.2.start" : "animation.s7d_parkour.humanoid.slide.1.start";
            
            p.playAnimation(anim, { blendOutTime: 0.2 });
            StateManager.setInfo(p.name, 'slide', {
                start: tick, duration: 14, knockback: 0.85,
                lastUpdate: tick, anim, yaw: alt ? p.getRotation().y : null
            });

            StaminaManager.startDrain(p, 2, 'slide');
            s.distance = 0;
        }

        if (s.sliding) {
            this.handleSliding(p, tick, s);
        }
    }

    handleSliding(p, tick, s) {
        const info = s.info;
        if (!info) return;

        const scan = BlockScanner.scan(p, tick, {
            needObstacle: true,
            needGap: true,
            needMovement: true,
            needLiquid: true
        });
        if (scan.liquid) {
            this.end(p, tick);
            return;
        }

        if (StaminaManager.get(p) <= 0 || tick - info.start > 14 || !p.isSneaking) {
            this.end(p, tick);
            return;
        }
        
        if (scan.obstacle) {
            this.end(p, tick);
            return;
        }

        const timeDiff = (tick - info.lastUpdate) / 20;
        info.knockback *= Math.pow(0.35, timeDiff);
        info.lastUpdate = tick;

        const yawRad = info.anim === "animation.s7d_parkour.humanoid.slide.2.start" && info.yaw !== null
            ? (info.yaw + 90) * Math.PI / 180
            : (p.getRotation().y + 90) * Math.PI / 180;

        const feetCheck = p.dimension.getBlockFromRay(
            { x: p.location.x, y: p.location.y, z: p.location.z },
            { x: Math.cos(yawRad), y: -1, z: Math.sin(yawRad) },
            { maxDistance: 1, includePassableBlocks: false, includeLiquidBlocks: false }
        );

        const lastUp = this.lastUpKnockback.get(p.name);
        const inUpWindow = lastUp && tick - lastUp < 3;
        
        let elevation;
        const hasBlockAhead = feetCheck?.block && !feetCheck.block.isAir;
        
        if (scan.gap.low && hasBlockAhead) {
            elevation = 0;
        } else if (inUpWindow) {
            elevation = 0.04;
        } else if (p.isOnGround) {
            elevation = 0.04;
            this.lastUpKnockback.set(p.name, tick);
        } else {
            elevation = -0.14;
        }
        
        p.applyKnockback({
            x: Math.cos(yawRad) * info.knockback,
            z: Math.sin(yawRad) * info.knockback
        }, elevation);

        p.dimension.playSound("step.grass", p.location, { pitch: 1.0, volume: 0.9 });

        const vel = p.getVelocity();
        if (vel && Math.sqrt(vel.x ** 2 + vel.z ** 2) > 0.15) {
            const molang = new MolangVariableMap();
            molang.setFloat("variable.direction_x", Math.cos(yawRad));
            molang.setFloat("variable.direction_z", Math.sin(yawRad));
            molang.setFloat("variable.direction_y", 0);
            
            p.dimension.spawnParticle("s7d_parkour:trail", {
                x: p.location.x - vel.x * 0.3,
                y: p.location.y,
                z: p.location.z - vel.z * 0.3
            }, molang);
        }

        const lastScan = this.lastScan.get(p.name);
        
        if (this.shouldTeleport(lastScan, scan) && scan.movement.has) {
            const newLoc = {
                x: p.location.x + scan.movement.x * 0.05,
                y: p.location.y + 0.12,
                z: p.location.z + scan.movement.z * 0.05
            };
            if (p.tryTeleport(newLoc)) p.teleport(newLoc);
        }
        this.lastScan.set(p.name, scan);
    }

    updateSprint(p, tick, s) {
        const state = StateManager.get(p.name);
        if (!state || !state.slide) return;
        
        if (p.isSprinting) {
            if (!s.lastPos) {
                s.lastPos = {...p.location};
                return;
            }

            const dx = p.location.x - s.lastPos.x;
            const dz = p.location.z - s.lastPos.z;
            const dist = Math.sqrt(dx * dx + dz * dz);

            if (dist > 0.1) {
                s.distance += dist;
                s.lastPos = {...p.location};
            }
        } else {
            if (s.lastPos) {
                s.endTime = tick;
                s.lastPos = null;
            }
            if (s.endTime && tick - s.endTime > 1) {
                s.distance = 0;
            }
        }
    }

    shouldTeleport(lastScan, currentScan) {
        if (!lastScan || !currentScan) return false;
        
        const { gap: lastGap } = lastScan;
        const { gap: currentGap } = currentScan;
        
        return currentGap.low && !lastGap.low;
    }

    end(p, tick) {
        const state = StateManager.get(p.name);
        if (!state || !state.slide) return;
        if (!state) return;
        
        state.slide.sliding = false;
        state.slide.distance = 0;
        
        if (p.isSneaking) {
            state.slide.sneakHeldFromSlide = true;
        }
        
        const endAnim = state.slide.info?.anim === "animation.s7d_parkour.humanoid.slide.2.start" ?
            "animation.s7d_parkour.humanoid.slide.2.end" : "animation.s7d_parkour.humanoid.slide.1.end";
            
        StateManager.clearInfo(p.name, 'slide', tick);
        p.playAnimation(endAnim, { blendOutTime: 0.2 });
        
        StaminaManager.stopDrain(p, 'slide');
        
        this.lastScan.delete(p.name);
        this.lastUpKnockback.delete(p.name);
        this.lastTick.delete(p.name);
    }

    cleanup() {
        this.lastTick.clear();
        this.lastScan.clear();
        this.lastUpKnockback.clear();
    }
}