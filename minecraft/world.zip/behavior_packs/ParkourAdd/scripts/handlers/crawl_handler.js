import { system } from '@minecraft/server';
import { SkillManager } from '../managers/skill_manager.js';
import { StateManager } from '../managers/player_state_manager.js';
import { StaminaManager } from '../managers/stamina_manager.js';
import { BlockScanner } from '../utils/block_scanner.js';

const SOUNDS = {
    "minecraft:stone": "step.stone", "minecraft:dirt": "step.gravel",
    "minecraft:grass_block": "step.grass", "minecraft:sand": "step.sand"
};
const DEFAULT = { sound: "step.grass", pitch: 1.0, volume: 1.5 };

export class CrawlHandler {
    constructor() {
        this.lastTick = new Map();
        this.crawlingStates = new Map();
    }

    handle(p, tick) {
        if (this.lastTick.get(p.name) === tick) return;

        if (!SkillManager.isUnlocked(p, 'crawl')) return;
        this.lastTick.set(p.name, tick);

        if (!StaminaManager.has(p, 0, 'crawl')) return;

        const state = StateManager.get(p.name);
        if (!state) return;
        const { crawl: c, slide, roll } = state;

        if (!p.isOnGround || !p.isSneaking || p.isSprinting || p.isInLiquid) return;
        
        if (slide?.sliding || roll?.rolling) return;

        const vel = p.getVelocity();
        const moving = vel && Math.hypot(vel.x, vel.z) > 0.0001;
        const alreadyCrawling = Math.abs(p.location.y - p.getHeadLocation().y) < 0.301;

        this.crawlingStates.set(p.name, alreadyCrawling);

        if (moving && !alreadyCrawling) {
            const scan = BlockScanner.scan(p, tick, {
                needGap: true,
                needObstacle: true,
                needGround: true,
                needMovement: true,
                needLiquid: true
            });
            
            if (scan.liquid || scan.obstacle || !scan.gap.low) return;
            
            if (scan.movement.has && StaminaManager.consume(p, 6, 'crawl')) {
                c.crawling = true;
                c.start = tick;
                StateManager.setInfo(p.name, 'crawl', { start: tick });

                const newLoc = {
                    x: p.location.x + scan.movement.x * 0.05,
                    y: p.location.y + 0.12,
                    z: p.location.z + scan.movement.z * 0.05
                };

                if (p.tryTeleport(newLoc)) {
                    p.teleport(newLoc);
                    p.dimension.playSound(SOUNDS[scan.ground.block?.typeId] || DEFAULT.sound, p.location, DEFAULT);
                }

                system.runTimeout(() => {
                    c.crawling = false;
                    c.last = tick;
                    StateManager.clearInfo(p.name, 'crawl', tick);
                    this.crawlingStates.delete(p.name);
                    this.lastTick.delete(p.name);
                }, 1);
            }
        }
    }

    cleanup() {
        this.crawlingStates.clear();
    }
}